#
# Серверное приложение для соединений
#
import asyncio
from asyncio import transports


class ServerProtocol(asyncio.Protocol):
    login: str = None
    server: 'Server'
    transport: transports.Transport
    login_list = []
    history_list = []

    def __init__(self, server: 'Server'):
        self.server = server

    def data_received(self, data: bytes):
        print(data)
        decoded = data.decode()
        if decoded != "\r\n":
            if self.login is not None:
                self.send_message(decoded)
            else:
                if decoded.startswith("login:"):
                    curr_log = decoded.replace("login:", "").replace("\r\n", "")
                    if curr_log not in self.login_list:
                        self.login = curr_log
                        self.login_list.append(curr_log)
                        self.transport.write(
                            f"Привет, {self.login}!\r\n".encode()
                        )
                        self.send_history()
                    else:
                        self.transport.write(f"Логин {curr_log} занят, попробуйте другой.\r\n".encode())
                else:
                    self.transport.write("Неправильный логин\r\n".encode())



    def connection_made(self, transport: transports.Transport):
        self.server.clients.append(self)
        self.transport = transport
        self.transport.write("Добро пожаловать в чат! Для регистрации введите login:{ваш логин}\r\n\n".encode())
        print("Новое подключение")

    def connection_lost(self, exception):
        self.login_list.remove(self.login)
        self.server.clients.remove(self)
        print(f"Клиент {self.login} вышел")

    def send_message(self, content: str):
        if content !="\r\n":
            message = f"{self.login}: {content}\r\n"
            if len(self.history_list) == 10:
                self.history_list.remove(self.history_list[0])
            self.history_list.append(message)

            for user in self.server.clients:            #переслать сообщение всем пользователям
                user.transport.write(message.encode())
    def send_history(self):
        if len(self.history_list)>0:
            self.transport.write(f"Последние {len(self.history_list)} сообщений\r\n\n".encode())
            for _ in self.history_list:
                self.transport.write(_.encode())

class Server:
    clients: list

    def __init__(self):
        self.clients = []

    def build_protocol(self):
        return ServerProtocol(self)

    async def start(self):
        loop = asyncio.get_running_loop()

        coroutine = await loop.create_server(
            self.build_protocol,
            '127.0.0.1',
            #'192.168.1.101',
            8888
        )

        print("Сервер запущен ...")

        await coroutine.serve_forever()


process = Server()

try:
    asyncio.run(process.start())
except KeyboardInterrupt:
    print("Сервер остановлен вручную")
